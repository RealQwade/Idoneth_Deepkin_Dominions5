Welcome to my 1st mod, my attempt at the Idoneth Deepkin, I have attempted to capture the feel and lore of the Idoneth so I will explain a bit.


Lets talk about some of the nation effects, how they work together, and how I believe it captures the feel of the Idoneth.

As a dying race this is pretty easy to translate: Starting scale of D1, you can spend Pretender Points to move into growth of course and I think this
is a fair transaction. With half growth/death scales Growth 3 is a bit pricey, especially with a national version of Blood Fecundity. Downside
is the national version "Soul Transference" set to cost Astral gems. Upside as the Idoneth you can use specific commanders to extract Astral gems when you
Raid. Keeping with the lore as the Idoneth are forced to raid to capture souls to keep the species going. You can of course go further into Death Scales,
this puts you into a Raid or perish situation. Conversely with Growth scales you are less reliant on "Soul Transference" this is both
costly in Pretender Points, as well as not having as much effect due to half scales. This is intentional as it allows for you to strike the balance that suites
your needs. 

As a dying nation, you fortunately have some quite effective units, you are capital reliant and limited recruitment makes going full scales 
somewhat challenging, again this is intentional allowing you to strike your balance. The good news is you have the ability to summon sacred units at your capital,
as a dying nation it is not exactly efficient, the good news is you have the potential to supplement this inefficiency by Raiding. 

Continued raiding will provide you with a fair amount of gems, it also makes those provinces less valuable to seize more so with the nature of the
Idoneth, where and how you strike this balance is a difficult but rewarding balance you need to strike. It also in my view allows for more threat-response 
game play then say sitting around and cultivating pearls. 

With low numbers of your better troops, you are not likely to have a massive amount of them, the good news is your national spells help with a focus
on both buffing your units and attempting to control the battlefield, this can allow for some surprising upsets and helps emphasize that your troops
are important because every life is precious. 

Due to the nature of the Idoneth, cooperation is extremely important each of the three casts has a role to play and plays it with grim determination. 
With a lore focus on the magic of the soul you have good Astral/Death magic, This makes you a powerful communion nation, due to the utility of your
mages you have a lot of fringe benefits perhaps greatest of all is Healers, this helps encourage you to harass your foes with more favorable attacks
such as mind hunt. An ideal attacking force is always backed up by mages even when the mages do not take to the field. 

Yes there is an elephant in the room, my sprite work is...not the best. I am still working on it and actively seeking out artists to assist. 

The Idoneth has been played several times with my local play group, but insular play groups tend to develop unusual play patterns, any input would be
greatly appreciated. 

The Idoneth Deepkin mod is in full compliance with Sombre Warhammer 2.3, and I have looked to many of his units in an attempt to achieve a similar balance level. 
I am not affiliated with Sombre in any way shape or form, and I cannot stress that enough. 

Many thanks to Sombre, Aether Nomad, and the modding community. 

